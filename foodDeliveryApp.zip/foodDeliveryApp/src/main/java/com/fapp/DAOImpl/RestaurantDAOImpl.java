package com.fapp.DAOImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.fapp.DAO.RestaurantDAO;
import com.fapp.modals.Restaurants;
import com.fapp.util.DBConnection;

public class RestaurantDAOImpl implements RestaurantDAO {

    @Override
    public List<Restaurants> getAllRestaurants() {
        List<Restaurants> list = new ArrayList<>();
        String sql = "SELECT * FROM restaurants";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Restaurants r = extractRestaurantFromResultSet(rs);
                
                Restaurants res= new Restaurants(r.getRestaurantId(),r.getName(),r.getAddress(),r.getPhoneNumber(), r.getCuisineType()
                		, r.getDeliveryTime(),r.getAdminUserId(), r.getRating(), r.isActive(), r.getImagePath());
                
                list.add(res);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public Restaurants getRestaurantById(int id) {
        String sql = "SELECT * FROM restaurants WHERE restaurantId = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return extractRestaurantFromResultSet(rs);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void addRestaurant(Restaurants r) {
        String sql = "INSERT INTO restaurants (name, address, phoneNumber, cuisine_type, delivery_time, admin_user_id, rating, isActive, imagepath) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            setRestaurantParams(ps, r);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void updateRestaurant(Restaurants r) {
        String sql = "UPDATE restaurants SET name=?, address=?, phoneNumber=?, cuisine_type=?, delivery_time=?, admin_user_id=?, rating=?, isActive=?, imagepath=? WHERE restaurantId=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            setRestaurantParams(ps, r);
            ps.setInt(10, r.getRestaurantId());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteRestaurant(int id) {
        String sql = "DELETE FROM restaurants WHERE restaurantId = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Helper methods
    private Restaurants extractRestaurantFromResultSet(ResultSet rs) throws SQLException {
        Restaurants r = new Restaurants();
        r.setRestaurantId(rs.getInt("restaurantId"));
        r.setName(rs.getString("name"));
        r.setAddress(rs.getString("address"));
        r.setPhoneNumber(rs.getString("phoneNumber"));
        r.setCuisineType(rs.getString("cuisine_type"));
        r.setDeliveryTime(rs.getInt("delivery_time"));
        r.setAdminUserId(rs.getInt("admin_user_id"));
        r.setRating(rs.getDouble("rating"));
        r.setActive(rs.getBoolean("isActive")); // Tinyint(1) maps correctly to boolean
        r.setImagePath(rs.getString("imagepath"));
        return r;
    }

    private void setRestaurantParams(PreparedStatement ps, Restaurants r) throws SQLException {
        ps.setString(1, r.getName());
        ps.setString(2, r.getAddress());
        ps.setString(3, r.getPhoneNumber());
        ps.setString(4, r.getCuisineType());
        ps.setInt(5, r.getDeliveryTime());
        ps.setInt(6, r.getAdminUserId());
        ps.setDouble(7, r.getRating());
        ps.setBoolean(8, r.isActive());
        ps.setString(9, r.getImagePath());
    }
}
