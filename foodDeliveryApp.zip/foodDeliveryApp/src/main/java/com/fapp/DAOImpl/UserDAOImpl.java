package com.fapp.DAOImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.*;

import com.fapp.DAO.userDAO;
import com.fapp.modals.User;
import com.fapp.util.DBConnection;

public class UserDAOImpl implements userDAO {
	
	private String INSERT= "INSERT into user(name, username, password, email, phoneNumber, address, role,"
			+ "created_date, last_login_date) values (?,?,?,?,?,?,?,?,?)";
	
	private String UPDATE="update user set name = ?, username = ?, password = ?, email = ?, phoneNumber = ?, address = ?, role = ? where userId = ?";
	
	private String GET_USERBY_ID= "select * from user where userId = ?";

	private String GET_ALL_USERS= "select *from user";
	
	private String DELETE= "delete from user where userId = ?";
	
	@Override
	public List<User> getAllUsers() {
		ArrayList<User> users= new ArrayList<User>();
		try(Connection connection= DBConnection.getConnection();
				PreparedStatement preparedStatement= connection.prepareStatement(GET_ALL_USERS);)
		{	
//			preparedStatement.setInt(1, id);
			ResultSet result=  preparedStatement.executeQuery();	
			
			while(result.next()) {
				int ide= result.getInt(1);
				String name= result.getString(2);
				String username= result.getString(3);
				String password= result.getString(4);
				String email= result.getString(5);
				String phone= result.getString(6);
				String address= result.getString(7);
				String role= result.getString(8);
				Timestamp created_date= result.getTimestamp(9);				
				Timestamp last_login_date= result.getTimestamp(10);
				
				User u= new User(ide,name, username,password,email, phone, address, role, created_date,last_login_date);
				
				users.add(u);
			}
		}  catch (SQLException e) {
			e.printStackTrace();
		}
		return users;
	}

	@Override
	public User getUserById(int id) {
		
		User u= null;
		try(Connection connection= DBConnection.getConnection();
				PreparedStatement preparedStatement= connection.prepareStatement(GET_USERBY_ID);)
		{	
			preparedStatement.setInt(1, id);
			ResultSet result=  preparedStatement.executeQuery();	
			
			while(result.next()) {
				int ide= result.getInt(1);
				String name= result.getString(2);
				String username= result.getString(3);
				String password= result.getString(4);
				String email= result.getString(5);
				String phone= result.getString(6);
				String address= result.getString(7);
				String role= result.getString(8);
				Timestamp created_date= result.getTimestamp(9);				
				Timestamp last_login_date= result.getTimestamp(10);
				
				u= new User(ide,name, username,password,email, phone, address, role, created_date,last_login_date);
			}
		}  catch (SQLException e) {
			e.printStackTrace();
		}
		return u;
	}

	@Override
	public boolean addUser(User u) {
		
		int i=0;
		try(Connection connection= DBConnection.getConnection();
				PreparedStatement preparedStatement= connection.prepareStatement(INSERT);)
		{
					
			preparedStatement.setString(1, u.getName());
			preparedStatement.setString(2, u.getUsername());
			preparedStatement.setString(3, u.getPassword());
			preparedStatement.setString(4, u.getEmail());
			preparedStatement.setString(5, u.getPhoneNumber());
			preparedStatement.setString(6, u.getAddress());
			preparedStatement.setString(7, u.getRole());
			preparedStatement.setTimestamp(8, new Timestamp(System.currentTimeMillis()));
			preparedStatement.setTimestamp(9, new Timestamp(System.currentTimeMillis()));
			
			 i=preparedStatement.executeUpdate();
			
			
		}  catch (SQLException e) {
			e.printStackTrace();
		}
		return i>0;
	}

	@Override
	public void updateUser(User u) {
		try(Connection connection= DBConnection.getConnection();
				PreparedStatement preparedStatement= connection.prepareStatement(UPDATE);)
		{
			preparedStatement.setString(1, u.getName());
			preparedStatement.setString(2, u.getUsername());
			preparedStatement.setString(3, u.getPassword());
			preparedStatement.setString(4, u.getEmail());
			preparedStatement.setString(5, u.getPhoneNumber());
			preparedStatement.setString(6, u.getAddress());
			preparedStatement.setString(7, u.getRole());
			preparedStatement.setInt(8, u.getUserId());
			
			int i = preparedStatement.executeUpdate();
			System.out.println(i);
			
		}  catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void deleteUser(int id) {
		
		try(Connection connection= DBConnection.getConnection();
				PreparedStatement preparedStatement= connection.prepareStatement(DELETE);)
		{
			preparedStatement.setInt(1, id);
			int i = preparedStatement.executeUpdate();
			System.out.println(i);
			
		}  catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	public User getUserByEmail(String email) {
        String sql = "SELECT * FROM user WHERE email=?";
        try(Connection connection= DBConnection.getConnection();
				PreparedStatement preparedStatement= connection.prepareStatement(sql);){
        	preparedStatement.setString(1, email);
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {
                return new User(rs.getInt("userId"), rs.getString("name"), email, rs.getString("password"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
	
	 public boolean updatePasswordByEmail(String email, String newPassword) {
	        String sql = "UPDATE user SET password=? WHERE email=?";
	        try(Connection connection= DBConnection.getConnection();
					PreparedStatement preparedStatement= connection.prepareStatement(sql);){
	        	preparedStatement.setString(1, newPassword);
	        	preparedStatement.setString(2, email);
	            return preparedStatement.executeUpdate() > 0;
	        } catch (SQLException e) {
	            e.printStackTrace();
	            return false;
	        }
	    }

	 public User getUserByEmailPassword(String email, String password) {
		    String sql = "SELECT * FROM user WHERE email=? AND password=?";
		    try (Connection connection = DBConnection.getConnection();
		         PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

		        preparedStatement.setString(1, email);
		        preparedStatement.setString(2, password);
		        ResultSet rs = preparedStatement.executeQuery();

		        if (rs.next()) {
		            return new User(
		                rs.getInt("userId"),
		                rs.getString("name"),
		                rs.getString("username"),
		                rs.getString("password"),
		                rs.getString("email"),
		                rs.getString("phoneNumber"),
		                rs.getString("address"),
		                rs.getString("role"),
		                rs.getTimestamp("created_date"),
		                rs.getTimestamp("last_login_date")
		            );
		        }
		    } catch (SQLException e) {
		        e.printStackTrace();
		    }
		    return null; // return null if user not found
		}


}
