package com.fapp.DAOImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.fapp.DAO.OrdersDAO;
import com.fapp.modals.Orders;
import com.fapp.util.DBConnection;

public class OrdersDAOImpl implements OrdersDAO {

    @Override
    public List<Orders> getAllOrders() {
        List<Orders> list = new ArrayList<>();
        String sql = "SELECT * FROM orders";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Orders order= extractOrder(rs);
                
                Orders orders= new Orders( order.getRestaurantId(), order.getUserId(), order.getOrderDate(), order.getTotalAmount(),
                		order.getStatus(), order.getPaymentMode(), order.getAddress());
                
                list.add(orders);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public Orders getOrderById(int id) {
        String sql = "SELECT * FROM orders WHERE orderId=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return extractOrder(rs);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public int addOrder(Orders o) {
    	
    	int generatedOrderId= -1;
        String sql = "INSERT INTO orders (restaurantId, userId, orderDate, totalAmount, status, paymentMode, address) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            setOrderParams(ps, o);
            int i=ps.executeUpdate();
            
            if(i == 0) {
            	throw new SQLException("Creating order failed, try again");
            }
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    generatedOrderId = rs.getInt(1);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return generatedOrderId;
    }

    @Override
    public void updateOrder(Orders o) {
        String sql = "UPDATE orders SET restaurantId=?, userId=?, orderDate=?, totalAmount=?, status=?, paymentMode=?, address= ? WHERE orderId=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            setOrderParams(ps, o);
            ps.setInt(7, o.getOrderId());
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteOrder(int id) {
        String sql = "DELETE FROM orders WHERE orderId=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Orders> getOrdersByUserId(int userId) {
        List<Orders> list = new ArrayList<>();
        String sql = "SELECT * FROM orders WHERE userId=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
            	Orders order= extractOrder(rs);
                
                Orders orders= new Orders( order.getRestaurantId(), order.getUserId(), order.getOrderDate(), order.getTotalAmount(),
                		order.getStatus(), order.getPaymentMode(),order.getAddress());
                
                list.add(orders);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<Orders> getOrdersByRestaurantId(int restaurantId) {
        List<Orders> list = new ArrayList<>();
        String sql = "SELECT * FROM orders WHERE restaurantId=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, restaurantId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
            	Orders order= extractOrder(rs);
                
                Orders orders= new Orders( order.getRestaurantId(), order.getUserId(), order.getOrderDate(), order.getTotalAmount(),
                		order.getStatus(), order.getPaymentMode(), order.getAddress());
                
                list.add(orders);            
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Helper methods
    private Orders extractOrder(ResultSet rs) throws SQLException {
        Orders o = new Orders();
        o.setOrderId(rs.getInt("orderId"));
        o.setRestaurantId(rs.getInt("restaurantId"));
        o.setUserId(rs.getInt("userId"));
        o.setOrderDate(rs.getTimestamp("orderDate"));
        o.setTotalAmount(rs.getDouble("totalAmount"));
        o.setStatus(rs.getString("status"));
        o.setPaymentMode(rs.getString("paymentMode"));
        o.setAddress(rs.getString("address"));
        return o;
    }

    private void setOrderParams(PreparedStatement ps, Orders o) throws SQLException {
        ps.setInt(1, o.getRestaurantId());
        ps.setInt(2, o.getUserId());
        ps.setTimestamp(3, o.getOrderDate());
        ps.setDouble(4, o.getTotalAmount());
        ps.setString(5, o.getStatus());
        ps.setString(6, o.getPaymentMode());
        ps.setString(7, o.getAddress());
    }
}
