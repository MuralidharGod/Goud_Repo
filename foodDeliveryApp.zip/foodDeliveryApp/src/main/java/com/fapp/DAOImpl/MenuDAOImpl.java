package com.fapp.DAOImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.fapp.DAO.MenuDAO;
import com.fapp.modals.Menu;
import com.fapp.util.DBConnection;

public class MenuDAOImpl implements MenuDAO {

    @Override
    public List<Menu> getAllMenuItems() {
        List<Menu> list = new ArrayList<>();
        String sql = "SELECT * FROM menu";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
               Menu m= extractMenuFromResultSet(rs);
               
               Menu menu= new Menu(m.getMenuId(), m.getRestaurantId(), m.getItemName(), m.getDescription(), m.getPrice(), m.isAvailable(), m.getRatings(), m.getImagePath()); 
               
               list.add(menu);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public Menu getMenuItemById(int id) {
        String sql = "SELECT * FROM menu WHERE menuId = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return extractMenuFromResultSet(rs);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void addMenuItem(Menu m) {
        String sql = "INSERT INTO menu (restaurantId, itemName, description, price, isAvailable, ratings, imagepath) " +
                     "VALUES (?, ?, ?, ?, ?,?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            setMenuParams(ps, m);
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void updateMenuItem(Menu m) {
        String sql = "UPDATE menu SET restaurantId=?, itemName=?, description=?, price=?, isAvailable=?,ratings=?, imagepath=? " +
                     "WHERE menuId=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            setMenuParams(ps, m);
            ps.setInt(7, m.getMenuId());
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteMenuItem(int id) {
        String sql = "DELETE FROM menu WHERE menuId=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Menu> getMenuByRestaurantId(int restaurantId) {
        List<Menu> list = new ArrayList<>();
        String sql = "SELECT * FROM menu WHERE restaurantId = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, restaurantId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
            	list.add(extractMenuFromResultSet(rs));
             }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Helper method to extract menu from ResultSet
    private Menu extractMenuFromResultSet(ResultSet rs) throws SQLException {
        Menu m = new Menu();
        m.setMenuId(rs.getInt("menuId"));
        m.setRestaurantId(rs.getInt("restaurantId"));
        m.setItemName(rs.getString("itemName"));
        m.setDescription(rs.getString("description"));
        m.setPrice(rs.getDouble("price"));
        m.setAvailable(rs.getBoolean("isAvailable"));
        m.setImagePath(rs.getString("imagePath"));
        return m;
    }

    private void setMenuParams(PreparedStatement ps, Menu m) throws SQLException {
        ps.setInt(1, m.getRestaurantId());
        ps.setString(2, m.getItemName());
        ps.setString(3, m.getDescription());
        ps.setDouble(4, m.getPrice());
        ps.setBoolean(5, m.isAvailable());
        ps.setString(6, m.getImagePath());
    }
}
