package com.fapp.DAOImpl;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.fapp.DAO.OrderItemsDAO;
import com.fapp.modals.OrderItems;
import com.fapp.util.DBConnection;

public class OrderItemsDAOImpl implements OrderItemsDAO {

    @Override
    public List<OrderItems> getAllOrderItems() {
        List<OrderItems> list = new ArrayList<>();
        String sql = "SELECT * FROM orderitems";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
               OrderItems items= extractOrderItem(rs);
               
               OrderItems item= new OrderItems( items.getOrderId(), items.getMenuId(),items.getQuantity(), items.getTotalAmount());
               
               list.add(item);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public OrderItems getOrderItemById(int id) {
        String sql = "SELECT * FROM orderitems WHERE orderItemId=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return extractOrderItem(rs);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void addOrderItem(OrderItems item) {
        String sql = "INSERT INTO orderitems (orderId, menuId, quantity, totalAmount) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            setOrderItemParams(ps, item);
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void updateOrderItem(OrderItems item) {
        String sql = "UPDATE orderitems SET orderId=?, menuId=?, quantity=?, totalAmount=? WHERE orderItemId=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            setOrderItemParams(ps, item);
            ps.setInt(5, item.getOrderItemId());
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteOrderItem(int id) {
        String sql = "DELETE FROM orderitems WHERE orderItemId=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<OrderItems> getOrderItemsByOrderId(int orderId) {
        List<OrderItems> list = new ArrayList<>();
        String sql = "SELECT * FROM orderitems WHERE orderId=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, orderId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
            	OrderItems items= extractOrderItem(rs);
                
                OrderItems item= new OrderItems( items.getOrderId(), items.getMenuId(),items.getQuantity(), items.getTotalAmount());
                
                list.add(item);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Helper methods
    private OrderItems extractOrderItem(ResultSet rs) throws SQLException {
        OrderItems item = new OrderItems();
        item.setOrderItemId(rs.getInt("orderItemId"));
        item.setOrderId(rs.getInt("orderId"));
        item.setMenuId(rs.getInt("menuId"));
        item.setQuantity(rs.getInt("quantity"));
        item.setTotalAmount(rs.getDouble("totalAmount"));
        return item;
    }

    private void setOrderItemParams(PreparedStatement ps, OrderItems item) throws SQLException {
        ps.setInt(1, item.getOrderId());
        ps.setInt(2, item.getMenuId());
        ps.setInt(3, item.getQuantity());
        ps.setDouble(4, item.getTotalAmount());
    }
}
