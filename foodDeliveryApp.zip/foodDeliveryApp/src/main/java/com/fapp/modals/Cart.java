package com.fapp.modals;

import java.util.*;


public class Cart {
	private HashMap<Integer, CartItem> items;
	
	public Cart() {
		this.items= new HashMap<>();
	}
	
	 public HashMap<Integer, CartItem> getItems() {
	        return items;
	 }
	// Add an item to the cart
    public void addItem(CartItem newItem) {
        int itemId = newItem.getItemId();
        if (items.containsKey(itemId)) {
            // If item already exists, just increase quantity
            CartItem existingItem = items.get(itemId);
            existingItem.setQuantity(existingItem.getQuantity() + newItem.getQuantity());
        } else {
            items.put(itemId, newItem);
        }
        
        System.out.println(items);
    }

    // Update an item's quantity or price
    public void updateItem(int itemId, int newQuantity) {
        if (items.containsKey(itemId)) {
        	
            CartItem item = items.get(itemId);
            
            if(newQuantity <= 0) {
            	items.remove(itemId);
            	
            } else {
	            item.setQuantity(newQuantity);
//	            CartItem existingItem = items.get(itemId);
//	            item.setPrice(existingItem.getPrice()+item.getPrice());
	            }
            
        } else {
            System.out.println("Item not found in cart.");
        }
    }

    // Delete an item from the cart
    public void removeItem(int itemId) {
    	
        if (items.containsKey(itemId)) {
            items.remove(itemId);
        } else {
            System.out.println("Item not found in cart.");
        }
    }
    
   // Clear cart
    public void clearCart() {
        items.clear();
    }

    // Get total price
    public double getTotalPrice() {
        double total = 0;
        for (CartItem item : items.values()) {
            total += item.getPrice() * item.getQuantity();
        }
        return total;
    }
    
    public void prit(int id) {
    	CartItem it= items.get(id);
    	System.out.println(it);
    }
    
}
