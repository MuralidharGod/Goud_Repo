package com.fapp.DAO;

import java.util.List;

import com.fapp.modals.OrderItems;

public interface OrderItemsDAO {
    List<OrderItems> getAllOrderItems();
    OrderItems getOrderItemById(int id);
    void addOrderItem(OrderItems item);
    void updateOrderItem(OrderItems item);
    void deleteOrderItem(int id);
    List<OrderItems> getOrderItemsByOrderId(int orderId);
}
