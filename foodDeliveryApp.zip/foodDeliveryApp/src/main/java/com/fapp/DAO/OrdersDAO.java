package com.fapp.DAO;

import java.util.List;

import com.fapp.modals.Orders;

public interface OrdersDAO {
    List<Orders> getAllOrders();
    Orders getOrderById(int id);
    int addOrder(Orders o);
    void updateOrder(Orders o);
    void deleteOrder(int id);
    List<Orders> getOrdersByUserId(int userId);
    List<Orders> getOrdersByRestaurantId(int restaurantId);
}
