package com.fapp.DAO;

import java.util.List;

import com.fapp.modals.Menu;

public interface MenuDAO {
    List<Menu> getAllMenuItems();
    Menu getMenuItemById(int id);
    void addMenuItem(Menu m);
    void updateMenuItem(Menu m);
    void deleteMenuItem(int id);
    List<Menu> getMenuByRestaurantId(int restaurantId);
}

