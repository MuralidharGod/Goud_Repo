package com.fapp.DAO;

import java.util.List;

import com.fapp.modals.User;

public interface userDAO {
	List<User> getAllUsers();
	User getUserById(int id);
	boolean addUser(User u);
	void updateUser(User u);
	void deleteUser(int id);
}
