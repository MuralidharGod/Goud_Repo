package com.fapp.DAO;
import java.util.List;
import com.fapp.modals.Restaurants;

public interface RestaurantDAO {
	    List<Restaurants> getAllRestaurants();
	    Restaurants getRestaurantById(int id);
	    void addRestaurant(Restaurants restaurant);
	    void updateRestaurant(Restaurants restaurant);
	    void deleteRestaurant(int id);
	
}
