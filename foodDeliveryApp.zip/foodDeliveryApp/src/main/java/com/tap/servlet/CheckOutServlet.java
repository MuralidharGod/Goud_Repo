package com.tap.servlet;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;

import com.fapp.DAOImpl.OrderItemsDAOImpl;
import com.fapp.DAOImpl.OrdersDAOImpl;
import com.fapp.modals.Cart;
import com.fapp.modals.CartItem;
import com.fapp.modals.OrderItems;
import com.fapp.modals.Orders;
import com.fapp.modals.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/checkout")
public class CheckOutServlet extends HttpServlet {
	
	private OrdersDAOImpl orderDao;
	private OrderItemsDAOImpl orderItemDao;
	
	@Override
	public void init() {
		orderDao= new OrdersDAOImpl();
		orderItemDao= new OrderItemsDAOImpl();
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		HttpSession session= req.getSession();
		Cart cart= (Cart) session.getAttribute("cart");
		//System.out.println(cart);
		User user= (User) session.getAttribute("loggedInUser");
		//System.out.println(user);
		
		//System.out.println("Hiis from checkout servlet");
		
		int restaurantId= (int)session.getAttribute("restaurantId");
		
		if(cart != null && user != null && !cart.getItems().isEmpty()) {
			//System.out.println("Hiis from checkout servlet if condition");

			String paymentMethod= req.getParameter("paymentMethod");
			String address= req.getParameter("address");
			
			Orders order= new Orders();
			order.setUserId(user.getUserId());
			order.setRestaurantId(restaurantId);
			order.setAddress(address);
			order.setOrderDate(new Timestamp(System.currentTimeMillis()));
			order.setPaymentMode(paymentMethod);
			order.setStatus("Pending");
			
		//	System.out.println(order);
			double totalAmount= 0;
			for(CartItem item: cart.getItems().values()) {
				totalAmount += item.getQuantity()*item.getPrice();
			}
			order.setTotalAmount(totalAmount);
			
			int order_id= orderDao.addOrder(order);
			
			
			for(CartItem item: cart.getItems().values()) {
				int itemId= item.getItemId();
				int quantity= item.getQuantity();
				double price= item.getPrice();
				double totalPrice= price*quantity;
				
				OrderItems orderItem= new OrderItems(order_id, itemId, quantity, totalPrice);
				
				orderItemDao.addOrderItem(orderItem);
			//	System.out.println(orderItem);
			}
			
			session.removeAttribute("cart");
		//	System.out.println("Cart removed successfully.");
			session.setAttribute("order", order);
			resp.sendRedirect("order_confirmation.jsp");
		}
		else {
		//	System.out.println("Hiis from checkout servlet else condition");

			resp.sendRedirect("cart.jsp");
		}
	}
}
