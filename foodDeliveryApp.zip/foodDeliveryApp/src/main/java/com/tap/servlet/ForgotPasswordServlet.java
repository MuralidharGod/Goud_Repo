package com.tap.servlet;

import java.io.IOException;

import com.fapp.DAOImpl.UserDAOImpl;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/forgotpassword")
public class ForgotPasswordServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String email = request.getParameter("email");
        String newPassword = request.getParameter("newPassword");

        UserDAOImpl userDAO = new UserDAOImpl();
        boolean updated = userDAO.updatePasswordByEmail(email, newPassword);
        if (updated) {
            response.sendRedirect("login.jsp");
        } else {
            response.getWriter().println("Email not found! ");
            response.getWriter().println("Try again</a>");
            response.sendRedirect("login.jsp");
        }
    }
}
