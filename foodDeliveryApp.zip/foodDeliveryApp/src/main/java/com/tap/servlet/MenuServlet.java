package com.tap.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.*;

import com.fapp.DAOImpl.MenuDAOImpl;
import com.fapp.modals.Menu;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/menu")
public class MenuServlet extends HttpServlet {

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		//System.out.println("Hii from menu servlet");
		
		HttpSession session= req.getSession();
		int restId= Integer.parseInt(req.getParameter("restaurantId"));
		//System.out.println(restId);
		
		MenuDAOImpl mdao= new MenuDAOImpl();
		List<Menu> allMenus= mdao.getMenuByRestaurantId(restId);
		
		/*
		 * for (Menu menu : allMenus) { System.out.println(menu); }
		 */
		
		req.setAttribute("allMenus", allMenus);
		
				
		RequestDispatcher rd= req.getRequestDispatcher("menu1.jsp");
		rd.forward(req, resp);
	}
}
