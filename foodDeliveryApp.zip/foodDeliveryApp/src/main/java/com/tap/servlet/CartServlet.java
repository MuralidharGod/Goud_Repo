package com.tap.servlet;

import java.io.IOException;

import com.fapp.DAOImpl.MenuDAOImpl;
import com.fapp.modals.Cart;
import com.fapp.modals.CartItem;
import com.fapp.modals.Menu;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/cart")
public class CartServlet extends HttpServlet {
	
	//int itemId= 1;
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		HttpSession session= req.getSession();
		
		//System.out.println("Hii from cart servlet");
		
		
		
		Cart cart= (Cart) session.getAttribute("cart");
		
		
		Integer oldRestaurantId= (Integer)session.getAttribute("restaurantId");
		oldRestaurantId= (oldRestaurantId != null) ? oldRestaurantId.intValue() : 0;
		
		
		int newRestaurantId = Integer.parseInt(req.getParameter("restaurantId"));
				
		if(cart == null && oldRestaurantId != newRestaurantId ) {
			cart= new Cart();
			
			session.setAttribute("cart", cart);
			session.setAttribute("restaurantId", newRestaurantId);
			
		}
		
		String action= req.getParameter("action");
		

		if(action.equals("add")) {
			try {
				//System.out.println("Add method called");
				addCartItem(req, cart);
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		}
		else if(action.equals("update")) {
			try {
				//System.out.println("Update method called");
				updateCartItem(req, cart);
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		}
		else if(action.equals("remove")) {
			try {
				//System.out.println("Remove method called");
				removeCartItem(req, cart);
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		}
		
		
		session.setAttribute("cart", cart);
        resp.sendRedirect("cart.jsp");
	}
	
	public void addCartItem(HttpServletRequest req, Cart cart) throws ClassNotFoundException{
		int itemId= Integer.parseInt(req.getParameter("itemId"));
		int quantity= Integer.parseInt(req.getParameter("quantity"));
		
		//cart= new Cart();
		MenuDAOImpl menuDao= new MenuDAOImpl();
		Menu menuItem= menuDao.getMenuItemById(itemId);
		
	//	System.out.println("The menu in cart servlet: "+menuItem);
		
		if(menuItem != null) {
			CartItem item= new CartItem(itemId, menuItem.getItemName(), quantity, menuItem.getPrice());
		
		
		cart.addItem(item);
		
		//cart.prit(itemId);
		}
	}
	
	public void updateCartItem(HttpServletRequest req, Cart cart) throws ClassNotFoundException{
		int itemId= Integer.parseInt(req.getParameter("itemId"));
		int quantity= Integer.parseInt(req.getParameter("quantity"));
		
		cart.updateItem(itemId, quantity);
	}
	
	public void removeCartItem(HttpServletRequest req, Cart cart) throws ClassNotFoundException{
		int itemId= Integer.parseInt(req.getParameter("itemId"));
		
		cart.removeItem(itemId);
	}
	
}

