package com.tap.servlet;

import java.io.IOException;

import com.fapp.DAOImpl.UserDAOImpl;
import com.fapp.modals.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/signup")
public class SignupServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String phoneNumber = request.getParameter("phoneNumber");
        String address = request.getParameter("address");
        String role = request.getParameter("role");

        User user = new User(name, username, password, email, phoneNumber, address, role);
        UserDAOImpl userDAO = new UserDAOImpl();

        boolean exists = userDAO.getUserByEmail(email) != null;
        if (exists) {
            response.getWriter().println("User already exists! <a href='signup.jsp'>Try again</a>");
        } else {
            boolean success = userDAO.addUser(user);
            if (success) {
                response.sendRedirect("login.jsp");
            } else {
                response.getWriter().println("Error in registration! <a href='signup.jsp'>Try again</a>");
            }
        }
    }
}
