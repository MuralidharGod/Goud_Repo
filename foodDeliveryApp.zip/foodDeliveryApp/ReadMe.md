# 🍔 Food Delivery Web App

A full-stack **Java-based food delivery platform** where users can browse restaurants, view menus, add items to their cart, and place orders. Inspired by platforms like Swiggy & Zomato.

---

## 🚀 Features

- 🔐 User Signup/Login (Customer & Restaurant Roles)
- 📋 View Restaurant Listings
- 🍽️ Browse Menus & Add to Cart
- 🛒 Cart Management (Quantity, Remove Items)
- 💳 Checkout & Order Confirmation
- 📬 Order Success with Animation
- 🎨 Modern Responsive UI (Swiggy-Inspired)

---

## 🛠️ Tech Stack

| Layer        | Technology                       |
|-------------|----------------------------------|
| Frontend     | HTML, CSS           |
| Backend      | Java (JSP + Servlets)           |
| Database     | MySQL                           |
| Styling      | Custom CSS (with smooth UI)     |
| Build Tool   | Apache Tomcat / Eclipse / IntelliJ |

---

## 📁 Folder Structure

📦 FoodDeliveryApp/
├── 📂 WebContent/
│ ├── 📄 index.jsp
│ ├── 📄 login.jsp
│ ├── 📄 signup.jsp
│ ├── 📄 menu.jsp
│ ├── 📄 viewcart.jsp
│ ├── 📄 checkout.jsp
│ ├── 📄 orderconfirmation.jsp
│ └── 📄 forgotpassword.jsp
├── 📂 src/
│ ├── 📂 dao/
│ │ └── UserDAO.java, MenuDAO.java, OrderDAO.java, etc.
│ ├── 📂 model/
│ │ └── User.java, MenuItem.java, CartItem.java, etc.
│ └── 📂 servlet/
│ └── LoginServlet.java, CartServlet.java, OrderServlet.java, etc.
├── 📂 sql/
│ └── food_delivery_schema.sql
└── 📄 README.md

## 🧑‍💻 How to Run Locally

1. **Clone the Repo**
   ```bash
   git clone https://github.com/MuralidharGod/Goud_Repo

Import into IDE (Eclipse/IntelliJ)

Import as Dynamic Web Project

Setup Tomcat server

Setup Database

Start MySQL

Run food_delivery_schema.sql in MySQL

Update DB credentials in DBConnection.java

Run Project

Start Tomcat Server

Visit: http://localhost:8080/FoodDeliveryApp/

🛠️ Future Enhancements
📦 Real-time Order Tracking (Progress UI)

📱 Responsive Mobile App Version

🔔 Push Notifications

💬 Chat between user & restaurant

🌐 Admin Dashboard for order analytics

