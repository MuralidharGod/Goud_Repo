# Quote API with Rate Limiting

A simple Spring Boot REST API that returns random inspirational quotes and enforces **IP-based rate limiting**.

## ✨ Features
- `GET /api/quote` → returns a random quote
- Rate limiting: **5 requests per IP per minute**
- Returns `429 Too Many Requests` with `Retry-After` header when exceeded
- Logs all requests (IP, URI, response status, response time)
- Optional: Switch to **Bucket4j** for production-grade rate limiting

---

## 🚀 Getting Started

### Prerequisites
- Java 17+
- Maven 3+

### Setup & Run
```bash
# Clone repository
git clone https://github.com/your-username/quote-api.git
cd quote-api

# Build & run
mvn clean package
java -jar target/quote-api-0.0.1-SNAPSHOT.jar
```

API runs at: `http://localhost:8080`

---

## 📌 Endpoints

### Get Random Quote
```bash
curl -i http://localhost:8080/api/quote
```

✅ Example response:
```json
{
  "quote": "The only way to do great work is to love what you do. - Steve Jobs"
}
```

🚫 When rate limit exceeded:
```json
{
  "error": "Rate limit exceeded. Try again in 45 seconds."
}
```

---

## 🧪 Running Tests
```bash
mvn test
```

---

## 🔥 Bonus: Using Bucket4j

For advanced rate limiting, we swapped the custom in-memory limiter with [Bucket4j](https://github.com/vladimir-bukhtoyarov/bucket4j).

Advantages:
- Token bucket algorithm
- Thread-safe & scalable
- Configurable refill rate

---

## 📂 Tech Stack
- Spring Boot (Web)
- Java 17
- JUnit 5
- Bucket4j (optional)
