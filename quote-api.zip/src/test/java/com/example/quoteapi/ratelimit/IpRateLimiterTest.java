package com.example.quoteapi.ratelimit;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class IpRateLimiterTest {

    @Test
    void allowsRequestsWithinLimit() {
        IpRateLimiter limiter = new IpRateLimiter(5, 60);

        for (int i = 0; i < 5; i++) {
            IpRateLimiter.RateLimitResult result = limiter.tryAcquire("127.0.0.1");
            assertTrue(result.allowed, "Request " + i + " should be allowed");
        }
    }

    @Test
    void blocksRequestsOverLimit() {
        IpRateLimiter limiter = new IpRateLimiter(3, 60);

        for (int i = 0; i < 3; i++) {
            assertTrue(limiter.tryAcquire("192.168.1.10").allowed);
        }

        IpRateLimiter.RateLimitResult blocked = limiter.tryAcquire("192.168.1.10");
        assertFalse(blocked.allowed);
        assertTrue(blocked.retryAfterSeconds > 0);
    }
}
