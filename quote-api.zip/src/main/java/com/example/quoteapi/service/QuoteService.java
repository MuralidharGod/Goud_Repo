package com.example.quoteapi.service;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Random;

@Service
public class QuoteService {
    private final List<String> quotes = List.of(
            "The only way to do great work is to love what you do. - Steve Jobs",
            "Be yourself; everyone else is already taken. - Oscar Wilde",
            "In the middle of difficulty lies opportunity. - Albert Einstein",
            "What you do today can improve all your tomorrows. - Ralph Marston",
            "Don't watch the clock; do what it does. Keep going. - Sam Levenson",
            "Success usually comes to those who are too busy to be looking for it. - Henry David Thoreau",
            "I have not failed. I've just found 10,000 ways that won't work. - Thomas A. Edison"
    );

    private final Random random = new Random();

    public String getRandomQuote() {
        int idx = random.nextInt(quotes.size());
        return quotes.get(idx);
    }
}
