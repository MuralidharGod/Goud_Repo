package com.example.quoteapi.ratelimit;

import io.github.bucket4j.Bandwidth;
import io.github.bucket4j.Bucket;
import io.github.bucket4j.Refill;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class Bucket4jRateLimiter {

    private final ConcurrentHashMap<String, Bucket> buckets = new ConcurrentHashMap<>();

    private final int limit = 5;
    private final Duration window = Duration.ofMinutes(1);

    public Bucket resolveBucket(String ip) {
        return buckets.computeIfAbsent(ip, this::newBucket);
    }

    private Bucket newBucket(String key) {
        Refill refill = Refill.greedy(limit, window);
        Bandwidth limitBandwidth = Bandwidth.classic(limit, refill);
        return Bucket.builder()
                .addLimit(limitBandwidth)
                .build();
    }
}
