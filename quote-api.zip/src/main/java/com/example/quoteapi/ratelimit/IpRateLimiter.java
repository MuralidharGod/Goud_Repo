package com.example.quoteapi.ratelimit;

import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class IpRateLimiter {

    private final ConcurrentHashMap<String, Deque<Long>> requestsByIp = new ConcurrentHashMap<>();

    private final int limit;
    private final int windowSeconds;

    public IpRateLimiter() {
        this.limit = 5;
        this.windowSeconds = 60;
    }

    public IpRateLimiter(int limit, int windowSeconds) {
        this.limit = limit;
        this.windowSeconds = windowSeconds;
    }

    public RateLimitResult tryAcquire(String ip) {
        long now = Instant.now().getEpochSecond();
        Deque<Long> deque = requestsByIp.computeIfAbsent(ip, k -> new ArrayDeque<>());

        synchronized (deque) {
            long threshold = now - windowSeconds;
            while (!deque.isEmpty() && deque.peekFirst() < threshold) {
                deque.pollFirst();
            }

            if (deque.size() >= limit) {
                long oldest = deque.peekFirst();
                int retrySeconds = (int) (windowSeconds - (now - oldest));
                if (retrySeconds < 0) retrySeconds = 0;
                return new RateLimitResult(false, retrySeconds);
            } else {
                deque.addLast(now);
                return new RateLimitResult(true, 0);
            }
        }
    }

    public static class RateLimitResult {
        public final boolean allowed;
        public final int retryAfterSeconds;

        public RateLimitResult(boolean allowed, int retryAfterSeconds) {
            this.allowed = allowed;
            this.retryAfterSeconds = retryAfterSeconds;
        }
    }
}
