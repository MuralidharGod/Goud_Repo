package com.example.quoteapi.controller;

import com.example.quoteapi.ratelimit.Bucket4jRateLimiter;
import com.example.quoteapi.service.QuoteService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class QuoteController {

    private final QuoteService quoteService;
    private final Bucket4jRateLimiter bucketLimiter;

    public QuoteController(QuoteService quoteService, Bucket4jRateLimiter bucketLimiter) {
        this.quoteService = quoteService;
        this.bucketLimiter = bucketLimiter;
    }

    @GetMapping("/quote")
    public ResponseEntity<?> getQuote(HttpServletRequest request) {
        String clientIp = extractClientIp(request);
        var bucket = bucketLimiter.resolveBucket(clientIp);

        if (!bucket.tryConsume(1)) {
            return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS)
                    .body(Map.of("error", "Rate limit exceeded. Try again later."));
        }

        String quote = quoteService.getRandomQuote();
        return ResponseEntity.ok(Map.of("quote", quote));
    }

    private String extractClientIp(HttpServletRequest request) {
        String xfHeader = request.getHeader("X-Forwarded-For");
        if (xfHeader != null && !xfHeader.isBlank()) {
            return xfHeader.split(",")[0].trim();
        }
        return request.getRemoteAddr();
    }
}
