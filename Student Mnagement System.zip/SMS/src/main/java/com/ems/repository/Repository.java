package com.ems.repository;

import org.springframework.data.repository.CrudRepository;

import com.ems.entity.Student;

public interface Repository extends CrudRepository<Student, Integer> {
	Student findById(int id);

}
