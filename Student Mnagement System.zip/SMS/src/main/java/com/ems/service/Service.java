package com.ems.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ems.entity.Student;
import com.ems.repository.Repository;

@Component
public class Service {
	@Autowired
	private Repository repo;

	public String addStudent(Student s) {
		if (repo.save(s) != null) {
			return "Student added successfully";
		} else {
			return "Not able to add";
		}
	}

	public List<Student> getAllStudents() {
		List<Student> allStudents = (List) repo.findAll();
		return allStudents;
	}

	public Student getStudentById(int sid) {
			if(repo.findById(sid) != null) {
				return repo.findById(sid);
			}
			return null
					;
	}

	public String updateStudent(int sid, Student s) {
		if(repo.findById(sid) != null) {
			Student stu= repo.findById(sid);
			stu.setName(s.getName());
			stu.setCourse(s.getCourse());
			stu.setEmail(s.getEmail());
			repo.save(stu);
			return "Student Updated";
		}
		else {
			return "Student not Updated";
		}
	}

	public void deleteStudent(int id) {
		repo.deleteById(id);
	}
	
	
}
