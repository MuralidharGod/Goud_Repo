package com.ems.controller;


import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import org.springframework.web.bind.annotation.RestController;

import com.ems.entity.Student;
import com.ems.service.Service;

@RestController
public class HomeController {
	
	@Autowired
	private Service service;
	
	@GetMapping("/")
	public String home() {
		return "Welcome to Student Management System";
	}
	
	@PostMapping("/addStudent")
	public String addStudent(@RequestBody Student s) {
		return service.addStudent(s);
	}
	
	@GetMapping("/getAllStudents")
	public List<Student> getAllStudents(){
		return service.getAllStudents();
	}
	
	@GetMapping("/getStudent/{id}")
	public Student getStudent(@PathVariable("id") int sid) {
		return service.getStudentById(sid);
	}
	
	@PutMapping("/updateStudent/{id}")
	public String updateStudent(@PathVariable("id") int sid, @RequestBody Student s) {
		return service.updateStudent(sid, s);
	}
	
	@DeleteMapping("/deleteStudent/{id}")
	public String deleteStudent(@PathVariable("id") int id) {
		service.deleteStudent(id);
		return "Student deleted successfully";
	}
}
