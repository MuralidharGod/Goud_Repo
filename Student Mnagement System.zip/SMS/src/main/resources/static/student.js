// Load students when page loads
window.onload = function() {
  fetch("/getAllStudents")
    .then(res => res.json())
    .then(data => {
      let tbody = document.querySelector("#studentTable tbody");
      tbody.innerHTML = "";
      data.forEach(s => {
        let row = `<tr>
                     <td>${s.id}</td>
                     <td>${s.name}</td>
                     <td>${s.email}</td>
                     <td>${s.course}</td>
                     <td>
                       <button onclick="editStudent(${s.id})">Edit</button>
                       <button onclick="deleteStudent(${s.id})">Delete</button>
                     </td>
                   </tr>`;
        tbody.innerHTML += row;
      });
    });
};

function deleteStudent(id) {
  if (confirm("Are you sure to delete this student?")) {
    fetch("/deleteStudent/" + id, { method: "DELETE" })
      .then(() => {
        alert("Deleted!");
        location.reload();
      });
  }
}

function editStudent(id) {
  window.location.href = "updateStudent.html?id=" + encodeURIComponent(id);
}
