import Cardheading from "./cardheading";
import Cardcontent from "./cardContent";
import Cardfooter from "./cardfooter";

function Card(props){
   return(
        <>
            <div className="card">
                <Cardheading recipe={props.recipe} ctime={props.ctime} ptime={props.ptime} />
                <Cardcontent serve={props.serve} difficulty= {props.difficulty} type={props.Type} image= {props.image}/>  
                <Cardfooter />
            </div>
        </>
   );
}

function Cards(){
    return(
        <>
        <h1 className="title"><span>Mini</span> Project</h1>
        <div className="container">
            <Card recipe="Masala Chai" ctime="5" ptime="10" serve="2" difficulty="Easy" Type="Beverage" image="./src/images/mchai.png" />  
            <Card recipe="Paneer Butter Masala" ctime="15" ptime="25" serve="4" difficulty="Medium" Type="Main Course" image="./src/images/pbm.png" />  
            <Card recipe="Aloo Paratha" ctime="10" ptime="20" serve="3" difficulty="Easy" Type="Breakfast" image="./src/images/ap.png"/>  
            <Card recipe="Chicken Biryani" ctime="20" ptime="40" serve="5" difficulty="Hard" Type="Main Course" image="./src/images/cb.png" />  
            <Card recipe="Gulab Jamun" ctime="15" ptime="30" serve="6" difficulty="Medium" Type="Dessert" image="./src/images/gj.png" />  
            <Card recipe="Vegetable Pulao" ctime="10" ptime="25" serve="4" difficulty="Easy" Type="Main Course" image="./src/images/vp.png"/>  
            <Card recipe="Mango Lassi" ctime="5" ptime="10" serve="2" difficulty="Easy" Type="Beverage" image="./src/images/ml.png" />  
            <Card recipe="Idli Sambhar" ctime="15" ptime="30" serve="4" difficulty="Medium" Type="Breakfast" image="./src/images/is.png" />  
        </div>
        </>
    );
}

export default Cards;