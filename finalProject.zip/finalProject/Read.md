# Wellbeing Bot

Wellbeing Bot is a healthcare chatbot designed to assist users with health-related queries, book appointments, set medication reminders, and provide general health tips. It uses a Flask backend, a trained machine learning model, and a user-friendly web interface.

## Features

- **Chat Interface**: Users can interact with the bot to get health-related advice.
- **Appointment Booking**: Allows users to book doctor appointments.
- **Medication Reminders**: Users can set reminders for their medications.
- **Chat History**: View past conversations with the bot.
- **Voice Input/Output**: Supports voice-based interaction.

## Project Structure
bot_ui.html # Frontend for the chatbot 
flask_app.py # Flask backend for handling API requests 
training_bot.py # Script for training the chatbot model  
intents.json # Dataset for chatbot intents  
words.pkl # Pickled vocabulary for the chatbot  
classes.pkl # Pickled classes for the chatbot  
chatbot_model.keras # Trained chatbot model

## Setup Instructions

### Prerequisites

- Python 3.7+
- Flask
- TensorFlow
- NLTK
- SQLite3
- TailwindCSS (for frontend styling)

### Installation

1. Clone the repository:
   ```bash
   git clone <repository-url>
   cd <repository-folder>

2. Install dependencies:
    pip install -r requirements.txt

3. Download NLTK data:
    import nltk
    nltk.download('punkt')
    nltk.download('wordnet')

4. Train the chatbot model:
    python training_bot.py

5. Initialize the database: The database is automatically initialized when you run the Flask app.

6. Start the Flask server:
    python flask_app.py

7. Open the frontend: Navigate to 
    http://localhost:5000/interface in your browser.

Usage
    Chat: Type or speak your health-related queries in the chat interface.
    Book Appointments: Use the "Appointments" tab to schedule a doctor's visit.
    Set Reminders: Use the "Medication Reminders" tab to set reminders for your medications.
    View Chat History: Access past conversations in the "Chat History" tab.

File Descriptions
    bot_ui.html: Implements the user interface using TailwindCSS and JavaScript.
    flask_app.py: Backend API for handling chat queries, appointments, reminders, and chat history.
    training_bot.py: Script for training the chatbot model using the intents.json dataset.

API Endpoints
    GET /query/<sentence>: Get a chatbot response for a user query.
    POST /book_appointment: Book a doctor's appointment.
    POST /set_reminder: Set a medication reminder.
    GET /chat_history: Retrieve chat history.
    GET /appointments: View all booked appointments.
    GET /reminders: View all medication reminders.

License
    This project is licensed under the MIT License.