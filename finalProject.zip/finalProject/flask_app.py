# Improved and Fixed Flask Backend for Healthcare Chatbot

import json
import logging
import pickle
import random
import re
import sqlite3
import nltk
import numpy as np
from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
from nltk.stem import WordNetLemmatizer
from tensorflow.keras.models import load_model

# === Initialization ===
lemmatizer = WordNetLemmatizer()
model = load_model("chatbot_model.keras")
words = pickle.load(open("words.pkl", "rb"))
classes = pickle.load(open("classes.pkl", "rb"))
intents = json.loads(open("intents.json", encoding="utf8").read())

# === Flask App ===
app = Flask(__name__)
CORS(app)

# === Database Setup ===
def init_db():
    conn = sqlite3.connect("healthcare.db")
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS appointments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            date TEXT NOT NULL,
            time TEXT NOT NULL,
            contact TEXT
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS reminders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user TEXT NOT NULL,
            medication TEXT NOT NULL,
            reminder_time TEXT NOT NULL,
            frequency TEXT
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS chat_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_message TEXT,
            bot_response TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)

    conn.commit()
    conn.close()

init_db()

# === Utility Functions ===
def clean_up_sentence(sentence):
    sentence_words = nltk.word_tokenize(sentence)
    sentence_words = [lemmatizer.lemmatize(word.lower()) for word in sentence_words]
    return sentence_words

def bag_of_words(sentence):
    sentence_words = clean_up_sentence(sentence)
    bag = [0] * len(words)
    for w in sentence_words:
        for i, word in enumerate(words):
            if word == w:
                bag[i] = 1
    return np.array(bag)

def predict_class(sentence):
    bow = bag_of_words(sentence)
    res = model.predict(np.array([bow]))[0]
    ERROR_THRESHOLD = 0.15
    results = [[i, r] for i, r in enumerate(res) if r > ERROR_THRESHOLD]
    results.sort(key=lambda x: x[1], reverse=True)
    return [{"intent": classes[r[0]], "probability": str(r[1])} for r in results]

def get_response(ints, intents_json):
    if not ints:
        return "Sorry, I couldn't understand your request."
    tag = ints[0]['intent']
    for intent in intents_json['intents']:
        if intent['tag'] == tag:
            return random.choice(intent['responses'])
    return "Sorry, I couldn't find a matching intent."

def extract_appointment_details(message):
    try:
        name = re.search(r"for (\w+)", message).group(1)
        date = re.search(r"on (\d{4}-\d{2}-\d{2})", message).group(1)
        time_ = re.search(r"at (\d{1,2}:\d{2} (?:AM|PM))", message).group(1)
        contact = re.search(r"contact (\d{10})", message).group(1)
        return name, date, time_, contact
    except:
        return None

def extract_reminder_details(message):
    try:
        user = re.search(r"for (\w+)", message).group(1)
        medication = re.search(r"to take (\w+)", message).group(1)
        time_ = re.search(r"at (\d{1,2}:\d{2} (?:AM|PM))", message).group(1)
        frequency = re.search(r"(daily|weekly|monthly)", message).group(1)
        return user, medication, time_, frequency
    except:
        return None

def decrypt(message):
    # Optional decryption logic placeholder
    return message

# === Routes ===
@app.route("/query/<sentence>")
def query(sentence):
    msg = decrypt(sentence)
    intent_list = predict_class(msg)
    response = get_response(intent_list, intents)

    intent = intent_list[0]['intent'] if intent_list else None

    # Handle dynamic actions
    if intent == "appointment":
        details = extract_appointment_details(msg)
        if details:
            name, date, time_, contact = details
            conn = sqlite3.connect("healthcare.db")
            cursor = conn.cursor()
            cursor.execute("INSERT INTO appointments (name, date, time, contact) VALUES (?, ?, ?, ?)",
                           (name, date, time_, contact))
            conn.commit()
            conn.close()
            response = "Your appointment has been successfully booked!"

    elif intent == "reminder":
        details = extract_reminder_details(msg)
        if details:
            user, medication, time_, frequency = details
            conn = sqlite3.connect("healthcare.db")
            cursor = conn.cursor()
            cursor.execute("INSERT INTO reminders (user, medication, reminder_time, frequency) VALUES (?, ?, ?, ?)",
                           (user, medication, time_, frequency))
            conn.commit()
            conn.close()
            response = "Your medication reminder has been set!"

    # Store chat history
    conn = sqlite3.connect("healthcare.db")
    cursor = conn.cursor()
    cursor.execute("INSERT INTO chat_history (user_message, bot_response) VALUES (?, ?)", (msg, response))
    conn.commit()
    conn.close()

    return jsonify({"top": {"response": response}})

@app.route("/chat_history")
def chat_history():
    offset = int(request.args.get("offset", 0))
    limit = int(request.args.get("limit", 50))

    conn = sqlite3.connect("healthcare.db")
    cursor = conn.cursor()
    cursor.execute("SELECT user_message, bot_response, timestamp FROM chat_history ORDER BY timestamp DESC LIMIT ? OFFSET ?", (limit, offset))
    rows = cursor.fetchall()
    conn.close()

    return jsonify([{"user": row[0], "bot": row[1], "timestamp": row[2]} for row in rows])

@app.route("/book_appointment", methods=["POST"])
def book_appointment():
    data = request.json
    if not all(k in data for k in ("name", "date", "time", "contact")):
        return jsonify({"status": "error", "message": "Missing required fields"}), 400

    conn = sqlite3.connect("healthcare.db")
    cursor = conn.cursor()
    cursor.execute("INSERT INTO appointments (name, date, time, contact) VALUES (?, ?, ?, ?)",
                   (data["name"], data["date"], data["time"], data["contact"]))
    conn.commit()
    conn.close()

    return jsonify({"status": "success", "message": "Appointment booked!"})

@app.route("/set_reminder", methods=["POST"])
def set_reminder():
    data = request.json
    if not all(k in data for k in ("user", "medication", "reminder_time", "frequency")):
        return jsonify({"status": "error", "message": "Missing required fields"}), 400

    conn = sqlite3.connect("healthcare.db")
    cursor = conn.cursor()
    cursor.execute("INSERT INTO reminders (user, medication, reminder_time, frequency) VALUES (?, ?, ?, ?)",
                   (data["user"], data["medication"], data["reminder_time"], data["frequency"]))
    conn.commit()
    conn.close()

    return jsonify({"status": "success", "message": "Reminder set!"})

@app.route("/appointments")
def get_appointments():
    conn = sqlite3.connect("healthcare.db")
    cursor = conn.cursor()
    cursor.execute("SELECT name, date, time, contact FROM appointments ORDER BY date, time")
    rows = cursor.fetchall()
    conn.close()
    return jsonify([{"name": row[0], "date": row[1], "time": row[2], "contact": row[3]} for row in rows])

@app.route("/reminders")
def get_reminders():
    conn = sqlite3.connect("healthcare.db")
    cursor = conn.cursor()
    cursor.execute("SELECT user, medication, reminder_time, frequency FROM reminders ORDER BY reminder_time")
    rows = cursor.fetchall()
    conn.close()
    return jsonify([{"user": row[0], "medication": row[1], "reminder_time": row[2], "frequency": row[3]} for row in rows])


@app.route("/")
def health_check():
    return jsonify({"status": "Wellbeing bot is running"})

@app.route("/interface")
def interface():
    return render_template("fend1.html")

if __name__ == '__main__':
    app.run(debug=True)
