import pickle
import nltk

# nltk.download('punkt')
# nltk.download('wordnet')
from nltk.stem import WordNetLemmatizer
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Activation, Dropout
from tensorflow.keras.optimizers import SGD
import os
import numpy as np
import random
import json

lemmatizer = WordNetLemmatizer()

if not os.path.exists("intents.json"):
	raise FileNotFoundError("intents.json file not found!")
intents = json.loads(open("intents.json").read())

if not os.path.exists("intents.json"):
	raise FileNotFoundError("intents.json file not found!")

words = []
classes = []
documents = []

ignore_letters = ["?", "!", ".", ","]

for intent in intents["intents"]:
	for pattern in intent["patterns"]:
		word_list = nltk.word_tokenize(pattern)
		words.extend(word_list)
		documents.append((word_list, intent["tag"]))

		if intent["tag"] not in classes:
			classes.append(intent["tag"])
words = [lemmatizer.lemmatize(word)
		for word in words if word not in ignore_letters]

words = sorted(set(words))
classes = sorted(set(classes))

pickle.dump(words, open('words.pkl', 'wb'))
pickle.dump(classes, open('classes.pkl', 'wb'))

dataset = []
template = [0]*len(classes)

for document in documents:
	bag = []
	word_patterns = document[0]
	word_patterns = [lemmatizer.lemmatize(word.lower())
					for word in word_patterns]

	for word in words:
		bag.append(1) if word in word_patterns else bag.append(0)

	output_row = list(template)
	output_row[classes.index(document[1])] = 1
	dataset.append([bag, output_row])

random.shuffle(dataset)
dataset = np.array(dataset, dtype=object)  # Allow mixed-type elements

train_x = np.array([item[0] for item in dataset], dtype=np.float32)
train_y = np.array([item[1] for item in dataset], dtype=np.float32)

if isinstance(dataset, np.ndarray):
	print("Dataset is a NumPy array")

# from sklearn.model_selection import train_test_split
# # Split your dataset
# train_x, test_x, train_y, test_y = train_test_split(train_x, train_y, test_size=0.2, random_state=42)


model = Sequential()
model.add(Dense(256, input_shape=(len(train_x[0]),),
				activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(128, activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(len(train_y[0]), activation='softmax'))


sgd = SGD(learning_rate=0.01,
		momentum=0.9, nesterov=True)
model.compile(loss='categorical_crossentropy',
			optimizer=sgd, metrics=['accuracy'])

# history = model.fit(np.array(train_x), np.array(train_y),
#                  epochs=100, batch_size=5, verbose=1,
#                  validation_data=(np.array(test_x), np.array(test_y)))

history = model.fit(np.array(train_x), np.array(train_y),
					epochs=100, batch_size=5, verbose=1)

model.save("chatbot_model.keras", history)
print("Done!")

# Visualisation of split_data
'''import matplotlib.pyplot as plt

# Plot accuracy
plt.figure(figsize=(12, 5))

plt.subplot(1, 2, 1)
plt.plot(history.history['accuracy'], label='Train Accuracy', color='blue')
plt.plot(history.history['val_accuracy'], label='Validation Accuracy', color='green')
plt.title('Accuracy Over Epochs')
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.legend()

# Plot loss
plt.subplot(1, 2, 2)
plt.plot(history.history['loss'], label='Train Loss', color='red')
plt.plot(history.history['val_loss'], label='Validation Loss', color='orange')
plt.title('Loss Over Epochs')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()

plt.tight_layout()
plt.show()	'''




from flask import Flask, render_template, request, jsonify
import random
import json
import pickle
import nltk
from nltk.stem import WordNetLemmatizer
from pyjsparser.parser import false
from tensorflow.keras.models import load_model
import numpy as np
import speech_recognition as sr
import pyttsx3
import time

# Initialize lemmatizer and load necessary files
lemmatizer = WordNetLemmatizer()

# Load intents and models
try:
	intents = json.loads(open("intents.json").read())
	words = pickle.load(open("words.pkl", "rb"))
	classes = pickle.load(open("classes.pkl", "rb"))
	model = load_model("chatbot_model.keras", compile=False)
except Exception as e:
	print(f"Error loading files: {e}")
	exit(1)  # Exit if critical files are missing or corrupted



def clean_up_sentence(sentence):
	sentence_words = nltk.word_tokenize(sentence)
	sentence_words = [lemmatizer.lemmatize(word) for word in sentence_words]
	return sentence_words


def bag_of_words(sentence):
	sentence_words = clean_up_sentence(sentence)
	bag = [0] * len(words)
	for w in sentence_words:
		for i, word in enumerate(words):
			if word == w:
				bag[i] = 1
	return np.array(bag)


def predict_class(sentence):
	bow = bag_of_words(sentence)
	res = model.predict(np.array([bow]))[0]
	ERROR_THRESHOLD = 0.15
	results = [[i, r] for i, r in enumerate(res) if r > ERROR_THRESHOLD]
	results.sort(key=lambda x: x[1], reverse=True)
	return [{"intent": classes[r[0]], "probability": str(r[1])} for r in results]


def get_response(intents_list, intents_json):
	tag = intents_list[0]["intent"] if intents_list else "no_match"
	for i in intents_json["intents"]:
		if i["tag"] == tag:
			return random.choice(i["responses"])
	return "I'm sorry, I couldn't find an appropriate response."

# print("Intent:", predict_class("I have a fever and cough"))


def call_bot(user_input):
	predictions = predict_class(user_input)
	response = get_response(predictions, intents)
	engine.say(f"I found this response: {response}")
	engine.runAndWait()
	print(f"Your symptom was: {user_input}")
	print(f"Result found in our Database: {response}")



# Main function
if __name__ == "__main__":

	print("Bot is Running")

	# Initialize speech recognition and text-to-speech engine
	recognizer = sr.Recognizer()
	mic = sr.Microphone()
	engine = pyttsx3.init()
	engine.setProperty("rate", 175)
	engine.setProperty("volume", 1.0)
	voices = engine.getProperty("voices")

	# Greeting
	# Greeting
	engine.say("Hello! I am Wellbeing bot, your personal talking healthcare chatbot.")
	engine.runAndWait()
	engine.say("If you want a male voice, please say 'male'. or If you want a female voice, please say 'female'.")
	engine.runAndWait()

	# Select voice
	try:
		with mic as source:
			print("Taking input for voice preference. Please say 'male' or 'female'.")
			recognizer.adjust_for_ambient_noise(source, duration=1.0)
			engine.say("Please say 'male' or 'female'.")
			engine.runAndWait()

			audio = recognizer.listen(source, timeout=5, phrase_time_limit=3)  # Set timeout
			voice_preference = recognizer.recognize_google(audio).lower()

			if "female" in voice_preference:
				engine.setProperty("voice", voices[1].id)
				print("Using Female Voice")
				engine.say("Using Female Voice")
			elif "male" in voice_preference:
				engine.setProperty("voice", voices[0].id)
				print("Using Male Voice")
				engine.say("Using Male Voice")
			else:
				print("Unrecognized input, using default male voice.")
				engine.say("I didn't understand, using default male voice.")
				engine.setProperty("voice", voices[0].id)

			engine.runAndWait()

	except sr.UnknownValueError:
		print("Could not understand voice input, using default male voice.")
		engine.say("Sorry, I couldn't understand your preference. Using the default male voice.")
		engine.setProperty("voice", voices[0].id)
		engine.runAndWait()
	except sr.RequestError as e:
		print(f"Speech recognition service error: {e}. Using default male voice.")
		engine.say("I'm facing some issues with speech recognition. Using the default male voice.")
		engine.setProperty("voice", voices[0].id)
		engine.runAndWait()
	except Exception as e:
		print(f"Unexpected error: {e}")
		engine.say("An unexpected error occurred. Using the default male voice.")
		engine.setProperty("voice", voices[0].id)
		engine.runAndWait()

	# Chat loop
	continue_chat = True  # Initialize the chat loop

	while continue_chat:
		try:
			print("Say your symptoms. The bot is listening.")
			engine.say("You may tell me your symptoms now. I am listening.")
			engine.runAndWait()

			with mic as source:
				recognizer.adjust_for_ambient_noise(source, duration=0.5)
				audio = recognizer.listen(source, timeout=10, phrase_time_limit=15)  # Timeout added
				user_input = recognizer.recognize_google(audio).strip().lower()
				print(f"You said: {user_input}")

			# Process the input
			call_bot(user_input)

		except sr.UnknownValueError:
			print("Couldn't understand. Please try again.")
			engine.say("I couldn't understand. Please repeat.")
			engine.runAndWait()
			continue  # Restart the loop

		except sr.RequestError:
			print("Network error. Please check your internet connection.")
			engine.say("I'm facing internet issues. Please check your connection.")
			engine.runAndWait()
			continue  # Restart the loop

		# Asking the user if they want to continue
		engine.say("Do you want to continue? Please say 'yes' or 'no'.")
		engine.runAndWait()

		try:
			with mic as source:
				recognizer.adjust_for_ambient_noise(source, duration=0.5)
				audio = recognizer.listen(source, timeout=10, phrase_time_limit=15)
				user_response = recognizer.recognize_google(audio).strip().lower()
				print(f"User response: {user_response}")

				# Check if user wants to continue
				ctnue: list[str] = ["yeah i want to continue", "yes continue", "yeah continue", "sure continue", "yes i want to continue"]
				if user_response in ctnue:
					continue_chat = True
				elif user_response in ["no", "nope", "stop", "exit", "quit"]:
					continue_chat = False
				else:
					print("Unclear response. Assuming 'No'.")
					engine.say("I didn't understand, so I will stop.")
					engine.runAndWait()
					continue_chat = False

		except sr.UnknownValueError:
			print("Didn't catch that, assuming 'no'.")
			engine.say("I couldn't understand, assuming you don't want to continue.")
			engine.runAndWait()
			continue_chat = False  # Stop continuing

		except sr.RequestError as e:
			print(f"Speech recognition service error: {e}. Assuming 'no'.")
			engine.say("I'm facing speech recognition issues. Assuming you don't want to continue.")
			engine.runAndWait()
			continue_chat = False

	print("Chatbot session ended.")
	engine.say("Thank you for using Wellbeing bot. Goodbye!")
	engine.runAndWait()
