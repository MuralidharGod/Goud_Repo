import json

# File paths to load
files = [('D:/finalProject/datasets/firstAid.json', "First Aid"),('D:/finalProject/datasets/healthFaq.json', "Health Faq"),('D:/finalProject/datasets/symptoms.json', "Symptoms")]
# Initialize an empty dictionary to hold merged data
'''merged_data = {"intents": []}

for file in files:
    try:
        with open(file, 'r') as f:
            data = json.load(f)
            # Get the first (and only) key dynamically (e.g., "intents", "first_aid", "health_faq")
            key = list(data.keys())[0]
            if isinstance(data[key], list):
                merged_data["intents"].extend(data[key])  # Append all records to common "intents"
            else:
                print(f" Warning: The key '{key}' in '{file}' does not contain a list.")
    except FileNotFoundError:
        print(f" Error: File '{file}' not found.")
    except json.JSONDecodeError:
        print(f" Error: File '{file}' contains invalid JSON.")
    except Exception as e:
        print(f" Error: An unexpected error occurred while processing '{file}': {e}")

# Save the merged file
with open('merged_intents.json', 'w') as f:
    json.dump(merged_data, f, indent=2)

print(" Merged all files into 'merged_intents.json'")'''

merged_data = {"intents": []}

for file_path, category in files:
    # Load the JSON file
    with open(file_path, 'r') as f:
        data = json.load(f)
        key = list(data.keys())[0]  # e.g., "intents", "first_aid", "health_faq"
        for item in data[key]:
            item["category"] = category
            merged_data["intents"].append(item)
            
# Save the merged file
with open('merged_intents.json', 'w') as f:
    json.dump(merged_data, f, indent=2)

print("Merged all files into 'merged_intents.json'")
