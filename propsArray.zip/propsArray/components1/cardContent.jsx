export default function Cardcontent(props){
    return(
        <section className="content">
            <div className="details">
                <p><span className="h">Serves</span> : {props.serve} people</p>
                <p><span className="h">Difficulty</span> : {props.difficulty}</p>
                <p><span className="h">Type</span> : {props.type}</p>
            </div>
            <img src={props.image} alt="recipe image" />
        </section>
    );
}