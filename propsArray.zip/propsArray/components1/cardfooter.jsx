export default function Cardfooter(){
    return(
        <footer className="footer">
            Delicious Recipes @2025
        </footer>
    );
}