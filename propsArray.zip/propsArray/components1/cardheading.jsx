export default function Cardheading(props){
    return (
        <header className="header">
            <h1>{props.recipe}</h1>
            <p>Prep Time : {props.ptime} minutes | Cook Time : {props.ctime} minutes</p>
        </header>
    );
}