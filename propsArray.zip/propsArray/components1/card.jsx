import Cardheading from "./cardheading";
import Cardcontent from "./cardContent";
import Cardfooter from "./cardfooter";
import Data  from "./Data.jsx";

function Card(props){
   return(
        <>
            <div className="card">
                <Cardheading recipe={props.item.recipe} ctime={props.item.ctime} ptime={props.item.ptime} />
                <Cardcontent serve={props.item.serve} difficulty= {props.item.difficulty} type={props.item.Type} image= {props.item.image}/>  
                <Cardfooter />
            </div>
        </>
   );
}

function Cards(){
    return(
        <>
        <h1 className="title"><span>Mini</span> Project</h1>
        <div className="container">
            {
                Data.map((item)=>
                    <Card item={item}/>
            )
            }
        </div>
        </>
    );
}

export default Cards;