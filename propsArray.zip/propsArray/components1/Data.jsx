export default [
    {
        recipe:"Masala Chai", ctime:"5", ptime:"10", serve:"2", difficulty:"Easy", Type:"Beverage", image:"./src/images/mchai.png"
    },
    {
        recipe:"Paneer Butter Masala", ctime:"15", ptime:"25", serve:"4", difficulty:"Medium", Type:"Main Course", image:"./src/images/pbm.png"
    },
    {
        recipe:"Aloo Paratha", ctime:"10", ptime:"20", serve:"3", difficulty:"Easy", Type:"Breakfast", image:"./src/images/ap.png"
    },
    {
        recipe:"Chicken Biryani", ctime:"20", ptime:"40", serve:"5", difficulty:"Hard", Type:"Main Course", image:"./src/images/cb.png"
    },
    {
        recipe:"Gulab Jamun", ctime:"15", ptime:"30", serve:"6", difficulty:"Medium", Type:"Dessert", image:"./src/images/gj.png"
    },
    {
        recipe:"Vegetable Pulao", ctime:"10", ptime:"25", serve:"4", difficulty:"Easy", Type:"Main Course", image:"./src/images/vp.png"
    },
    {
        recipe:"Mango Lassi", ctime:"5", ptime:"10", serve:"2", difficulty:"Easy", Type:"Beverage", image:"./src/images/ml.png"
    },
    {
        recipe:"Idli Sambhar", ctime:"15", ptime:"30", serve:"4", difficulty:"Medium", Type:"Breakfast", image:"./src/images/is.png"
    }
    
]